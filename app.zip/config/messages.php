<?php

return [
    'default' => [
        'error' => 'Sorry your request has not been processed correct, please try again later',
        'success' => 'your request has been processed successfully! '
    ]
];
