<!DOCTYPE HTML>
<html>
<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-174641914-1"></script>
    <script>


        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-174641914-1');
    </script>

    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=10,IE=9,IE=8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, height=device-height" />
    <title>King Author E-books</title>
{{--    <link rel="icon" type="image/x-icon" href="{{asset('frontend/assets/images/favicon.ico')}}"/>--}}
    <link href="{{asset('frontend/assets/css/custom.css')}}" rel="stylesheet" />
    <link href="{{asset('frontend/assets/css/jquery-ui.css')}}" rel="stylesheet" />
    <script src="{{asset('frontend/assets/js/jquery-3.1.1.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/assets/js/jquery-ui.js')}}" type="text/javascript"></script>
</head>

<script> $(document).ready(function() { $('.loading_cls').show(); $('#author_container').hide(); }); </script><script> $(document).ready(function() { $('.loading_cls').hide(); $('#author_container').show(); }); </script><script> $(document).ready(function() { $('.loading_cls').hide(); $('#author_container').show(); }); </script><script> $(document).ready(function() { $('.loading_cls').hide(); $('#author_container').show(); }); </script><script> $(document).ready(function() { $('.loading_cls').hide(); $('#author_container').show(); }); </script>
<body>
<div id="wrapper">
    <div id="app_header" class="app_header">
		<span>
            <a >
                <img alt="king author's Ebooks" src="{{asset('frontend/assets/images/KAlogo-01.png')}}" height="100px">
            </a>
        </span>
        <div class="app_header_right">
            <button onclick="search()"> Search </button>
            <input type="search" id="search_text" placeholder="Search by author or book"><br/>
            <b class="searching_cls"></b>
        </div>
        <div class="type_selection hide">
            <input type="radio" name="type" id="authors" value="authors" checked> <label for="authors">Authors</label>
            <input type="radio" name="type" id="books" value="books"> <label for="books">Books</label>
        </div>
    </div>

    <div id="content" class="content">

        <div id="treeview" class="treeview">
            <div class="treeview_header">
                <h4>Authors</h4>
            </div>
            <div class="clear_cont"></div>
            <ul id="author-list" class="dynatree-container dynatree-no-connector">
                @foreach($authors as $author)
                <li onclick="showListOfBooks(event, {{$author->id}} )" class="dynatree-lastsib" data-author-id="{{$author->id}}">
                    <!-- author container -->
                    <ul  id="author_container">
                        <li>
                            <!-- the author information -->
                            <span class="dynatree-node dynatree-folder dynatree-has-children dynatree-exp-c dynatree-ico-cf">
        							<span class="dynatree-expander"></span>
            						<span class="dynatree-icon"></span>
            						<a href="#" class="dynatree-title auth_dir" title="A. J. Hartley">{{$author->name}}</a>
        						</span>
                            <!-- the author information -->

                            <!-- books container for the author -->
                            <ul id="author-tree-{{$author->id}}" class="book_container hide">
                                @foreach($author->books as $book)
                                <!-- the first book -->
                                <li onclick="showDownloadBookList(event, {{$book->id}} )">

                                    <!-- the info of the book -->
                                    <span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">
        								<span class="dynatree-expander"></span>
        								<span class="dynatree-icon"></span>
        								<a href="#" class="dynatree-title book_dir" title="Act of Will">{{$book->name}}</a>
        							</span>
                                    <!-- the info of the book -->

                                    <!-- the file container first -->
                                    <ul id="files-tree-{{$book->id}}" class="file_container hide">

                                        <!-- the pdf book  -->
                                        <li>
                							<span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">
                								<span class="dynatree-connector"></span>
                								<span class="ui-icon ui-icon-document"></span>
                								<a href="{{route('books.download.mobi',$book->id)}}" class="dynatree-title file" title="book1" download="">{{$book->name}}</a>
                							</span>
                                        </li>
                                        <!-- the pdf book  -->

                                        <!-- the mobi book  -->
                                        <li>
                							<span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">
                								<span class="dynatree-connector"></span>
                								<span class="ui-icon 	ui-icon-note"></span>
                								<a href="{{route('books.download.pdf',$book->id)}}" class="dynatree-title file" title="mobiBook" download="">{{$book->name}}</a>
                							</span>
                                        </li>
                                        <!-- the mobi book  -->

                                    </ul>
                                    <!-- the file container first -->

                                </li>
                                <!-- the first book -->
                                @endforeach

                            </ul>
                            <!-- books container for the author -->


                        </li>
                        <!-- the second book -->

                    </ul>
                    <!-- author container -->
                </li>
                @endforeach
            </ul>
        </div>

        <div class="middle_section">
            <div class="mid_sec_text">
					<span class="text_center">
						<div><b>MORE THAN 10,000 FREE E-BOOKS</b></div>
						<div>MOBI (Kindle) and PDF (Universal) formats</div>
					</span>
                <br/>
                <ul>
                    <li>No account registration</li>
                    <li>No annoying ads</li>
                    <li>No viruses or malware</li>
                    <li>No page redirections</li>
                    <li>One-click download</li>
                </ul>
                <br/>
                <div class="text_center">
                    CAN'T FIND YOUR E-BOOK HERE? <br>
                    Send us your request by e-mail to: <br>
                    <a href="mailto:contact@kingauthor.net">contact@kingauthor.net</a>
                </div><p>
                <div class="mid_sec_bottom_text_section">
                    <p class="mid_sec_bottom_disclaimer">DISCLAIMER:</p>
                    <p class="mid_sec_bottom_text"><i>
                            This website is completely for free, generates no revenue, and its sole purpose is to provide books for the needy not the greedy.<br><br>
                            In 2017, the median annual income for published authors in the US was $6087.<br><br>
                            My website will surely not affect the Stephen Kings of the world, but the underdog writers who put their heart and soul to write great books without having the money to promote it on a big scale.<br><br>
                            If you can afford buying the book and support the writers to keep providing us with great masterpieces, I seriously recommend you to do so.
                        </i></p>
                </div>
            </div>

        </div>

        <div id="list_container" class="list_container">
            <div class="treeview_header">
                <h4>Books</h4>
            </div>
            <div class="clear_cont"></div>
            <div id="books-list" class="book_table">
                <table id="files" class="tablesorter">
                    <tbody id="files-tbody">

                    @foreach ($books as $book)
                        <tr class="list-of-books" data-book-id="{{$book->id}}">
                            <td>
                                <span class="ui-icon ui-icon-document">{{$book->name}}</span>
                                <a href="{{route('books.download.pdf',$book->id)}}" download>{{$book->name}} (PDF Version)</a>
                            </td>
                        </tr>


                        <tr>
                            <td>
                                <span class="ui-icon ui-icon-note">{{$book->name}} MOBI Version</span>
                                <a href="{{route('books.download.mobi',$book->id)}}" download>{{$book->name}} (MOBI Version)</a>
                            </td>
                        </tr>

                    @endforeach

                    </tbody>
                </table>
            </div>
        </div>

    </div>

</div>
</body>
</html>



<script type="text/javascript">

    var globalSearch = null;

    $(document).ready(()=>{
    })

    function search(){
        var currentSearch = $('#search_text').val()
        globalSearch = currentSearch;
        getDataAuthors(currentSearch)
        getDataBooks(currentSearch)
    }

    function clearChildren(parent){
        $(parent).empty()
    }

    function getDataAuthors(search = null){
        var currentRequestForAuthors = null;
        currentRequestForAuthors = $.ajax({
            url: "{{route('get.authors.after.search')}}",
            method : 'POST',
            dataType: "json",
            data:{
              '_token' : "{{csrf_token()}}",
                'search' : search,
            },
            success: (data) => {
                clearChildren('#author-list')
                printDataAuthors(data.data.authors)
            },
            error: (error) => {
               console.log(error)
            },
            beforeSend :() => {
                if(currentRequestForAuthors != null){
                    currentRequestForAuthors.abort()
                }
            },

        })
    }

    function getDataBooks(search = null){
        var currentRequestForBooks = null
        currentRequestForBooks = $.ajax({
            url: "{{route('get.books.after.search')}}",
            method : 'POST',
            dataType: "json",
            data:{
                '_token' : "{{csrf_token()}}",
                'search' : search
            },
            success: (data) => {
                clearChildren('#files')
                printDataBooks(data.data.books)
            },
            error: (error) => {
                console.log(error)
            },
            beforeSend :() => {
                if(currentRequestForBooks != null) {
                    currentRequestForBooks.abort();
                }
            }
        })
    }

    function getDataBooksAfterScroll(search = null,booksArray){

        $.ajax({
            url: "{{route('get.books.after.last.index')}}",
            method : 'POST',
            dataType: "json",
            data:{
                '_token' : "{{csrf_token()}}",
                'search' : search,
                'books' : booksArray,
            },
            success: (data) => {
                printDataBooks(data.data.books)
            },
            error: (error) => {
                console.log(error)
            },
            beforeSend :() => {

            }
        })
    }

    function getDataAuthorsAfterScroll(search = null,authorsArray){

        $.ajax({
            url: "{{route('get.authors.after.last.index')}}",
            method : 'POST',
            dataType: "json",
            data:{
                '_token' : "{{csrf_token()}}",
                'search' : search,
                'authors' : authorsArray,
            },
            success: (data) => {
                printDataAuthors(data.data.authors)
            },
            error: (error) => {
                console.log(error)
            },
            beforeSend :() => {

            }
        })
    }

    function printDataBooks(books){
        var rows = '<tbody>'

        books.forEach((book)=>{
            rows+= '<tr class="list-of-books" data-book-id="'+book.id+'">'+
                        '<td>'+
                            '<span class="ui-icon ui-icon-document"> '+ book.name +' </span>'+
                            ('<a href="{{route('books.download.pdf',['%book%'])}}" download>'+book.name+' (PDF Version)</a>').replace('%book%',book.id)+
                        '</td>'+
                   '<tr>'+

                   '<tr>'+
                        '<td>'+
                            '<span class="ui-icon ui-icon-note">'+book.name+' (MOBI Version)</span>'+
                            ('<a href="{{route('books.download.mobi',['%book%'])}}" download>'+book.name+' (MOBI Version)</a>').replace('%book%',book.id)+
                        '</td>'+
                    '</tr>'
        })

        rows+= '</tbody>'

        $('#files').append(rows)
    }

    function printDataAuthors(authors) {
        var rows = ''

        authors.forEach((author) => {
            var books = '';

            (author.books).forEach((book)=>{
                books +=
                '<li data-book-id="'+book.id+'" onclick="showDownloadBookList(event,'+book.id+')">'+
                '<span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">'+
                    '<span class="dynatree-expander"></span>'+
                    '<span class="dynatree-icon"></span>'+
                    '<a href="#" class="dynatree-title book_dir" title="Act of Will">'+book.name+'</a>'+
                '</span>'+
                '<ul id="files-tree-'+book.id+'"  class="file_container hide">'+
                    '<li>'+
                    '<span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">'+
                        '<span class="dynatree-connector"></span>'+
                        '<span class="ui-icon ui-icon-document"></span>'+
                        '<a href="" class="dynatree-title file" title="book1" download="">'+book.name+'</a>'+
                    '</span>'+
                    '</li>'+
                    '<li>'+
                        '<span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">'+
                        '<span class="dynatree-connector"></span>'+
                        '<span class="ui-icon 	ui-icon-note"></span>'+
                        '<a href="" class="dynatree-title file" title="mobiBook" download="">'+book.name+'</a>'+
                        '</span>'+
                    '</li>'+
                '</ul>'+
                '</li>'
            });


            rows += '<li onclick="showListOfBooks(event, '+author.id+')" class="dynatree-lastsib" data-author-id="'+author.id+'">'+
                        '<ul id="author_container">'+
                            '<li>'+
                                '<span class="dynatree-node dynatree-folder dynatree-has-children dynatree-exp-c dynatree-ico-cf">'+
                                    '<span class="dynatree-expander"></span>'+
                                    '<span class="dynatree-icon"></span>'+
                                    '<a href="#" class="dynatree-title auth_dir" title="'+author.name+'">'+author.name+'</a>'+
                                    '</span>'+
                                '<ul id="author-tree-'+author.id+'" class="book_container hide">'+
                                    books+
                                '</ul>' +
                            '</li>'+
                        '</ul>'+
                     '</li>'
        })

        $("#author-list").append(rows).change()

    }

    function showListOfBooks(e,id) {
       var element = $('#author-tree-'+id)
        if($(element).is(":hidden")){
            $(element).show().change()
            return ;
        }
        $(element).hide().change()
        return
    }

    function showDownloadBookList(e,id){
        e.stopPropagation()
        var element =$('#files-tree-'+id)
        if($(element).is(":hidden")){
            $(element).show().change()
            return ;
        }
        $(element).hide().change()
        return

    }

    $('#author-list').scroll(function() {
        if($(this).scrollTop() + $(this).innerHeight()+1 >= $(this)[0].scrollHeight) {
            var authorsArray = [];
            var authorsObjects = $.makeArray($('.dynatree-lastsib'))

            $.map(authorsObjects,(authorObject)=>{
                authorsArray.push($(authorObject).data('author-id'))
            })

            getDataAuthorsAfterScroll(globalSearch,authorsArray)

        }
    });

    $('#books-list').scroll(function() {
        if($(this).scrollTop() + $(this).innerHeight()+1 >= $(this)[0].scrollHeight) {
            var booksArray = [];
            var booksObjects = $.makeArray($('.list-of-books'))

            $.map(booksObjects,(bookObject)=>{
                booksArray.push($(bookObject).data('book-id'))
            })
            getDataBooksAfterScroll(globalSearch,booksArray)
        }
    });


    // $('#author-list').on('click','.dynatree-node.dynatree-folder.dynatree-has-children.dynatree-exp-c.dynatree-ico-cf',()=>{
    //     var element = $('#author-list').find('ul')[1]
    //     if($(element).is(":hidden")){
    //         $(element).show().change()
    //         return ;
    //     }
    //     $(element).hide().change()
    //     return
    // })

    // $('#author-list').on('click','.dynatree-node.dynatree-folder.dynatree-exp-c.dynatree-ico-cf',()=>{
    //     var element = $('#author-list').find('ul')[1]
    //     if($(element).is(":hidden")){
    //         $(element).show().change()
    //         return ;
    //     }
    //     $(element).hide().change()
    //     return
    // })

</script>

<script type="text/javascript">
    $(document).ready(function() {

        // $("a.auth_dir").click(function() {
        //     $(this).closest('li').find('ul.book_container').toggleClass('hide');
        //     $(this).closest('span.dynatree-node').toggleClass('dynatree-exp-e dynatree-active');
        // });

        // $("a.book_dir").click(function() {
        //     $(this).closest('li').find('ul.file_container').toggleClass('hide');
        //     $(this).closest('span.dynatree-node').toggleClass('dynatree-exp-e dynatree-active');
        // });

        /* Search author */
        // $("#search_text").keypress(function (evt) {
        //     var charCode = (evt.which) ? evt.which : event.keyCode;
        //     var search_text = $("#search_text").val().toLowerCase();
        //     if(charCode == 13 && search_text!="") {
        //         $.when( showSeachText() ).then(function() {
        //             /* search in authors */
        //             var authors = $("#author_container a.auth_dir");
        //             var author;
        //             var auth_result;
        //             for(var i=0; i<authors.length; i++) {
        //                 author = authors[i].text.toLowerCase();
        //                 auth_result = author.includes(search_text);
        //                 if(auth_result == true) {
        //                     /* reset all tree nodes */
        //                     authors[i].parentElement.parentElement.querySelector('ul.book_container').classList.add("hide");
        //                     authors[i].parentElement.parentElement.querySelector('span.dynatree-node').classList.remove("dynatree-exp-e");
        //                     authors[i].parentElement.parentElement.querySelector('span.dynatree-node').classList.remove("dynatree-active");
        //
        //                     authors[i].parentElement.parentElement.querySelector('ul.book_container ul.file_container').classList.add("hide");
        //                     authors[i].parentElement.parentElement.querySelector('ul.file_container span.dynatree-node').classList.remove("dynatree-exp-e");
        //                     authors[i].parentElement.parentElement.querySelector('ul.file_container span.dynatree-node').classList.remove("dynatree-active");
        //                     /* End: reset all tree nodes */
        //
        //                     authors[i].closest('li').style.display = "block";
        //                 } else {
        //                     authors[i].closest('li').style.display = "none";
        //                 }
        //             }
        //             /* End: search in authors */
        //
        //             /* search in files */
        //             var book_result;
        //             var book_array = {"books\\A. J. Hartley\\Act of Will\\Act of Will - A. J. Hartley.mobi":"Act of Will - A. J. Hartley.mobi","books\\A. J. Hartley\\Act of Will\\Act of Will - A. J. Hartley.pdf":"Act of Will - A. J. Hartley.pdf","books\\A. C. Crispin\\Star Wars The Han Solo Trilogy 1\\Star Wars The Han Solo Trilogy - A. C. Crispin.mobi":"Star Wars The Han Solo Trilogy - A. C. Crispin.mobi","books\\A. C. Crispin\\Star Wars The Han Solo Trilogy 2\\Star Wars The Han Solo Trilogy - A. C. Crispin.mobi":"Star Wars The Han Solo Trilogy - A. C. Crispin.mobi","books\\A. C. Crispin\\Star Wars The Han Solo Trilogy 3\\Star Wars The Han Solo Trilogy - A. C. Crispin.mobi":"Star Wars The Han Solo Trilogy - A. C. Crispin.mobi","books\\A. C. Crispin\\Star Wars The Han Solo Trilogy 1\\Star Wars The Han Solo Trilogy - A. C. Crispin.pdf":"Star Wars The Han Solo Trilogy - A. C. Crispin.pdf","books\\A. C. Crispin\\Star Wars The Han Solo Trilogy 2\\Star Wars The Han Solo Trilogy - A. C. Crispin.pdf":"Star Wars The Han Solo Trilogy - A. C. Crispin.pdf","books\\A. C. Crispin\\Star Wars The Han Solo Trilogy 3\\Star Wars The Han Solo Trilogy - A. C. Crispin.pdf":"Star Wars The Han Solo Trilogy - A. C. Crispin.pdf","books\\A. C. Crispin\\The Eyes of the Beholders\\The Eyes of the Beholders - A. C. Crispin.mobi":"The Eyes of the Beholders - A. C. Crispin.mobi","books\\A. C. Crispin\\The Eyes of the Beholders\\The Eyes of the Beholders - A. C. Crispin.pdf":"The Eyes of the Beholders - A. C. Crispin.pdf","books\\A. J. Jacobs\\The Know-it-All One Man's Humble Q\\The Know-it-All One Man's Humble Quest To Become The Smartest Person In The World - A. J. Jacobs.mobi":"The Know-it-All One Man's Humble Quest To Become The Smartest Person In The World - A. J. Jacobs.mobi","books\\A. J. Jacobs\\The Know-it-All One Man's Humble Q\\The Know-it-All One Man's Humble Quest To Become The Smartest Person In The World - A. J. Jacobs.pdf":"The Know-it-All One Man's Humble Quest To Become The Smartest Person In The World - A. J. Jacobs.pdf","books\\A. J. Liebling\\The Telephone Booth Indian\\The Telephone Booth Indian - A. J. Liebling.mobi":"The Telephone Booth Indian - A. J. Liebling.mobi","books\\A. J. Liebling\\The Telephone Booth Indian\\The Telephone Booth Indian - A. J. Liebling.pdf":"The Telephone Booth Indian - A. J. Liebling.pdf","books\\A. J. Hartley\\Will Power\\Will Power - A. J. Hartley.mobi":"Will Power - A. J. Hartley.mobi","books\\A. J. Hartley\\Will Power\\Will Power - A. J. Hartley.pdf":"Will Power - A. J. Hartley.pdf"};
        //             var file_type, file_type_class, file_content = "";
        //             var element  = document.getElementById('files');
        //             var fragment = document.createDocumentFragment();
        //             var tbody = document.createElement('tbody');
        //             fragment.appendChild(tbody);
        //
        //             // $.each(book_array, function(book_path, book) {
        //             //     book_result = book.toLowerCase().includes(search_text);
        //             //     if(book_result == true) {
        //             //         var pos = book_path.lastIndexOf(".");
        //             //         file_type = book_path.substr(pos+1);
        //             //         if(file_type=="mobi") { file_type_class = "ui-icon-document"; } else{ file_type_class = "ui-icon-note"; }
        //             //
        //             //         var tr = document.createElement('tr');
        //             //         tbody.appendChild(tr);
        //             //         var td = document.createElement('td');
        //             //         tr.appendChild(td);
        //             //         var span = document.createElement('span');
        //             //         span.className  = "ui-icon "+file_type_class;
        //             //         td.appendChild(span);
        //             //         var a = document.createElement('a');
        //             //         a.textContent = book;
        //             //         a.setAttribute('href', book_path);
        //             //         a.setAttribute('download', '');
        //             //         td.appendChild(a);
        //             //     }
        //             // });
        //
        //
        //             $("#files").html("");
        //             element.appendChild(fragment);
        //             /* End: search in files */
        //
        //             $('.searching_cls').html("Search complete. <span class='ui-icon ui-icon-close'></span>");
        //             $('.searching_cls .ui-icon-close').bind('click', function() {
        //                 $('.searching_cls').html('');
        //             });
        //         });
        //     }
        // });

        /* For mobile view */
        if ($(".treeview").css("float") == "none" ) {
            $(".type_selection").toggleClass("hide");
            /*$('input[type=radio][name=type]').change(function() {
                var type = $(this).val();
                if (type == 'authors') {
                    $(".list_container").hide();
                    $(".treeview").show();
                }else{
                    $(".treeview").hide();
                    $(".list_container").show();
                }
            });*/

            var _originalSize = $(window).width() + $(window).height();
            $(window).resize(function(){
                if($(window).width() + $(window).height() != _originalSize){
                    $(".middle_section").addClass("hide");
                }else{
                    $(".middle_section").removeClass("hide");
                }
            });
        }
        $('input[type=radio][name=type]').change(function() {
            var type = $(this).val();
            if (type == 'authors') {
                $(".list_container").hide();
                $(".treeview").show();
            }else{
                $(".treeview").hide();
                $(".list_container").show();
            }
        });
        /* End: For mobile view */

        window.showSeachText = function(msg) {
            $('.searching_cls').html("Searching... Please, wait.");
        }

        /*$.get('test.php', { width: screen.width, height:screen.height }, function(json) {
            //alert(Json.stringify(json));
        },'json');*/
    });
</script>


