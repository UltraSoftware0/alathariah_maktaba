<form method="post" enctype="multipart/form-data" action="{{route('test.upload')}}">
    @csrf
    <input name="file_upload" type="file" />
    <input type="submit" />

</form>

