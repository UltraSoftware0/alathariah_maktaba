<!DOCTYPE HTML>
<html>
    <head>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-174641914-1"></script>
        <script>


            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'UA-174641914-1');
        </script>

        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=10,IE=9,IE=8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, height=device-height" />
        <title>King Author E-books</title>
    {{--    <link rel="icon" type="image/x-icon" href="{{asset('frontend/assets/images/favicon.ico')}}"/>--}}
        <link href="{{asset('frontend/assets/css/custom.css')}}" rel="stylesheet" />
        <link href="{{asset('frontend/assets/css/jquery-ui.css')}}" rel="stylesheet" />

        <script src="{{asset('frontend/assets/js/jquery-3.1.1.js')}}" type="text/javascript"></script>
        <script src="{{asset('frontend/assets/js/jquery-ui.js')}}" type="text/javascript"></script>
        
        <script src="https://cdn.tailwindcss.com"></script>
    </head>

    <script> $(document).ready(function() { $('.loading_cls').show(); $('#author_container').hide(); }); </script><script> $(document).ready(function() { $('.loading_cls').hide(); $('#author_container').show(); }); </script><script> $(document).ready(function() { $('.loading_cls').hide(); $('#author_container').show(); }); </script><script> $(document).ready(function() { $('.loading_cls').hide(); $('#author_container').show(); }); </script><script> $(document).ready(function() { $('.loading_cls').hide(); $('#author_container').show(); }); </script>

    <body class="bg-gradient-to-b from-slate-200 to-black bg-fixed">
        <div class="bg-white border-x border-slate-500 border-solid lg:mx-20 xl:mx-44 min-h-screen">
            {{-- App Header --}}
            <div class="bg-gradient-to-b from-white to-slate-200">
                <div class="grid grid-cols-1 md:grid-cols-2">
                    <div>
                        <a href="#/">
                            <img alt="king author's Ebooks" src="{{asset('frontend/assets/images/KAlogo-01.png')}}" width="250">
                        </a>
                    </div>
                    <div class="flex justify-center items-center">
                        <button onclick="search()" class="px-2 py-0.5 mx-1 bg-slate-200 border border-solid border-slate-500"> Search </button>
                        <input type="search" class="px-2 py-0.5 mx-1 bg-white border border-solid border-slate-500" id="search_text" placeholder="Search by author or book"><br/>
                        <b class="searching_cls"></b>
                    </div>
                </div>
            </div>

            {{--  Type Selection --}}
            <div class="flex md:hidden justify-center items-center py-3 border-b border-solid border-slate-300">
                <input type="radio" name="type" id="authors" class="list-visibility-selection" value="authors" class="mx-1" checked>
                <label for="authors" class="mr-2">Authors</label>
                
                <input type="radio" name="type" id="books" class="list-visibility-selection" value="books" class="mx-1">
                <label for="books">Books</label>
            </div>

            {{-- Content --}}
            <div id="content" class="grid grid-cols-1 md:grid-cols-3 md:gap-4">
                {{-- Author --}}
                <div class="border-r border-solid border-slate-200 max-h-screen-minus-header overflow-y-auto" id="authors-list-container">
                    <h4 class="font-semibold p-3">Authors</h4>
                    <ul id="author-list" class="dynatree-container dynatree-no-connector">
                        @foreach($authors as $author)
                            <li onclick="showListOfBooks(event, {{$author->id}} )" class="dynatree-lastsib" data-author-id="{{$author->id}}">
                                <!-- author container -->
                                <ul  id="author_container">
                                    <li>
                                        <!-- the author information -->
                                        <span class="dynatree-node dynatree-folder dynatree-has-children dynatree-exp-c dynatree-ico-cf">
                                                <span class="dynatree-expander"></span>
                                                <span class="dynatree-icon"></span>
                                                <a href="#" class="dynatree-title auth_dir" title="A. J. Hartley">{{$author->name}}</a>
                                            </span>
                                        <!-- the author information -->

                                        <!-- books container for the author -->
                                        <ul id="author-tree-{{$author->id}}" class="book_container hide">
                                            @foreach($author->books as $book)
                                            <!-- the first book -->
                                            <li onclick="showDownloadBookList(event, {{$book->id}} )">

                                                <!-- the info of the book -->
                                                <span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">
                                                    <span class="dynatree-expander"></span>
                                                    <span class="dynatree-icon"></span>
                                                    <a href="#" class="dynatree-title book_dir" title="Act of Will">{{$book->name}}</a>
                                                </span>
                                                <!-- the info of the book -->

                                                <!-- the file container first -->
                                                <ul id="files-tree-{{$book->id}}" class="file_container hide">

                                                    <!-- the pdf book  -->
                                                    <li>
                                                        <span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">
                                                            <span class="dynatree-connector"></span>
                                                            <span class="ui-icon ui-icon-document"></span>
                                                            <a href="{{route('books.download.mobi',$book->id)}}" class="dynatree-title file" title="book1" download="">{{$book->name}}</a>
                                                        </span>
                                                    </li>
                                                    <!-- the pdf book  -->

                                                    <!-- the mobi book  -->
                                                    <li>
                                                        <span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">
                                                            <span class="dynatree-connector"></span>
                                                            <span class="ui-icon 	ui-icon-note"></span>
                                                            <a href="{{route('books.download.pdf',$book->id)}}" class="dynatree-title file" title="mobiBook" download="">{{$book->name}}</a>
                                                        </span>
                                                    </li>
                                                    <!-- the mobi book  -->

                                                </ul>
                                                <!-- the file container first -->

                                            </li>
                                            <!-- the first book -->
                                            @endforeach

                                        </ul>
                                        <!-- books container for the author -->


                                    </li>
                                    <!-- the second book -->

                                </ul>
                                <!-- author container -->
                            </li>
                        @endforeach
                    </ul>
                </div>

                {{-- Middle Section --}}
                <div class="border-t md:border-0 pt-2 pb-10" id="website-description-container">
                    <p class="text-center text-lg font-semibold">MORE THAN 10,000 FREE E-BOOKS</p>
                    <p class="text-center text-md font-semibold">MOBI (Kindle) and PDF (Universal) formats</p>
                    <br/>
                    <ul class="list-disc ml-2 pl-5">
                        <li>No account registration</li>
                        <li>No annoying ads</li>
                        <li>No viruses or malware</li>
                        <li>No page redirections</li>
                        <li>One-click download</li>
                    </ul>
                    <br/>
                    <p class="text-center text-md font-semibold">
                        CAN'T FIND YOUR E-BOOK HERE?
                        <br>
                        Send us your request by e-mail to:
                        <br>
                        <a class="text-blue-500 underline" href="mailto:contact@kingauthor.net">contact@kingauthor.net</a>
                    </p>
                    <p class="text-center text-red-500 font-semibold pt-20">DISCLAIMER:</p>
                    <p class="font-semibold">
                        <i>
                            This website is completely for free, generates no revenue, and its sole purpose is to provide books for the needy not the greedy.
                            <br><br>
                            In 2017, the median annual income for published authors in the US was $6087.<br><br>
                            My website will surely not affect the Stephen Kings of the world, but the underdog writers who put their heart and soul to write great books without having the money to promote it on a big scale.
                            <br><br>
                            If you can afford buying the book and support the writers to keep providing us with great masterpieces, I seriously recommend you to do so.
                        </i>
                    </p>
                </div>

                {{-- Books --}}
                <div class="border-l border-solid border-slate-200 max-h-screen-minus-header overflow-y-auto" id="books-list-container">
                    <h4 class="font-semibold p-3">Books</h4>
                    <div id="books-list" class="book_table">
                        <table id="files" class="tablesorter">
                            <tbody id="files-tbody">
                                @foreach ($books as $book)
                                    <tr class="list-of-books" data-book-id="{{$book->id}}">
                                        <td>
                                            <span class="ui-icon ui-icon-document">{{$book->name}}</span>
                                            <a href="{{route('books.download.pdf',$book->id)}}" download>{{$book->name}} (PDF Version)</a>
                                        </td>
                                    </tr>


                                    <tr>
                                        <td>
                                            <span class="ui-icon ui-icon-note">{{$book->name}} MOBI Version</span>
                                            <a href="{{route('books.download.mobi',$book->id)}}" download>{{$book->name}} (MOBI Version)</a>
                                        </td>
                                    </tr>

                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>



<script type="text/javascript">

    var globalSearch = null;

    $(document).ready(()=>{
    })

    function search(){
        var currentSearch = $('#search_text').val()
        globalSearch = currentSearch;
        getDataAuthors(currentSearch)
        getDataBooks(currentSearch)
    }

    function clearChildren(parent){
        $(parent).empty()
    }

    function getDataAuthors(search = null){
        var currentRequestForAuthors = null;
        currentRequestForAuthors = $.ajax({
            url: "{{route('get.authors.after.search')}}",
            method : 'POST',
            dataType: "json",
            data:{
              '_token' : "{{csrf_token()}}",
                'search' : search,
            },
            success: (data) => {
                clearChildren('#author-list')
                printDataAuthors(data.data.authors)
            },
            error: (error) => {
               console.log(error)
            },
            beforeSend :() => {
                if(currentRequestForAuthors != null){
                    currentRequestForAuthors.abort()
                }
            },

        })
    }

    function getDataBooks(search = null){
        var currentRequestForBooks = null
        currentRequestForBooks = $.ajax({
            url: "{{route('get.books.after.search')}}",
            method : 'POST',
            dataType: "json",
            data:{
                '_token' : "{{csrf_token()}}",
                'search' : search
            },
            success: (data) => {
                clearChildren('#files')
                printDataBooks(data.data.books)
            },
            error: (error) => {
                console.log(error)
            },
            beforeSend :() => {
                if(currentRequestForBooks != null) {
                    currentRequestForBooks.abort();
                }
            }
        })
    }

    function getDataBooksAfterScroll(search = null,booksArray){

        $.ajax({
            url: "{{route('get.books.after.last.index')}}",
            method : 'POST',
            dataType: "json",
            data:{
                '_token' : "{{csrf_token()}}",
                'search' : search,
                'books' : booksArray,
            },
            success: (data) => {
                printDataBooks(data.data.books)
            },
            error: (error) => {
                console.log(error)
            },
            beforeSend :() => {

            }
        })
    }

    function getDataAuthorsAfterScroll(search = null,authorsArray){

        $.ajax({
            url: "{{route('get.authors.after.last.index')}}",
            method : 'POST',
            dataType: "json",
            data:{
                '_token' : "{{csrf_token()}}",
                'search' : search,
                'authors' : authorsArray,
            },
            success: (data) => {
                printDataAuthors(data.data.authors)
            },
            error: (error) => {
                console.log(error)
            },
            beforeSend :() => {

            }
        })
    }

    function printDataBooks(books){
        var rows = '<tbody>'

        books.forEach((book)=>{
            rows+= '<tr class="list-of-books" data-book-id="'+book.id+'">'+
                        '<td>'+
                            '<span class="ui-icon ui-icon-document"> '+ book.name +' </span>'+
                            ('<a href="{{route('books.download.pdf',['%book%'])}}" download>'+book.name+' (PDF Version)</a>').replace('%book%',book.id)+
                        '</td>'+
                   '<tr>'+

                   '<tr>'+
                        '<td>'+
                            '<span class="ui-icon ui-icon-note">'+book.name+' (MOBI Version)</span>'+
                            ('<a href="{{route('books.download.mobi',['%book%'])}}" download>'+book.name+' (MOBI Version)</a>').replace('%book%',book.id)+
                        '</td>'+
                    '</tr>'
        })

        rows+= '</tbody>'

        $('#files').append(rows)
    }

    function printDataAuthors(authors) {
        var rows = ''

        authors.forEach((author) => {
            var books = '';

            (author.books).forEach((book)=>{
                books +=
                '<li data-book-id="'+book.id+'" onclick="showDownloadBookList(event,'+book.id+')">'+
                '<span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">'+
                    '<span class="dynatree-expander"></span>'+
                    '<span class="dynatree-icon"></span>'+
                    '<a href="#" class="dynatree-title book_dir" title="Act of Will">'+book.name+'</a>'+
                '</span>'+
                '<ul id="files-tree-'+book.id+'"  class="file_container hide">'+
                    '<li>'+
                    '<span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">'+
                        '<span class="dynatree-connector"></span>'+
                        '<span class="ui-icon ui-icon-document"></span>'+
                        '<a href="" class="dynatree-title file" title="book1" download="">'+book.name+'</a>'+
                    '</span>'+
                    '</li>'+
                    '<li>'+
                        '<span class="dynatree-node dynatree-folder dynatree-exp-c dynatree-ico-cf">'+
                        '<span class="dynatree-connector"></span>'+
                        '<span class="ui-icon 	ui-icon-note"></span>'+
                        '<a href="" class="dynatree-title file" title="mobiBook" download="">'+book.name+'</a>'+
                        '</span>'+
                    '</li>'+
                '</ul>'+
                '</li>'
            });


            rows += '<li onclick="showListOfBooks(event, '+author.id+')" class="dynatree-lastsib" data-author-id="'+author.id+'">'+
                        '<ul id="author_container">'+
                            '<li>'+
                                '<span class="dynatree-node dynatree-folder dynatree-has-children dynatree-exp-c dynatree-ico-cf">'+
                                    '<span class="dynatree-expander"></span>'+
                                    '<span class="dynatree-icon"></span>'+
                                    '<a href="#" class="dynatree-title auth_dir" title="'+author.name+'">'+author.name+'</a>'+
                                    '</span>'+
                                '<ul id="author-tree-'+author.id+'" class="book_container hide">'+
                                    books+
                                '</ul>' +
                            '</li>'+
                        '</ul>'+
                     '</li>'
        })

        $("#author-list").append(rows).change()

    }

    function showListOfBooks(e,id) {
       var element = $('#author-tree-'+id)
        if($(element).is(":hidden")){
            $(element).show().change()
            return ;
        }
        $(element).hide().change()
        return
    }

    function showDownloadBookList(e,id){
        e.stopPropagation()
        var element =$('#files-tree-'+id)
        if($(element).is(":hidden")){
            $(element).show().change()
            return ;
        }
        $(element).hide().change()
        return

    }

    $('#author-list').scroll(function() {
        if($(this).scrollTop() + $(this).innerHeight()+1 >= $(this)[0].scrollHeight) {
            var authorsArray = [];
            var authorsObjects = $.makeArray($('.dynatree-lastsib'))

            $.map(authorsObjects,(authorObject)=>{
                authorsArray.push($(authorObject).data('author-id'))
            })

            getDataAuthorsAfterScroll(globalSearch,authorsArray)

        }
    });

    $('#books-list').scroll(function() {
        if($(this).scrollTop() + $(this).innerHeight()+1 >= $(this)[0].scrollHeight) {
            var booksArray = [];
            var booksObjects = $.makeArray($('.list-of-books'))

            $.map(booksObjects,(bookObject)=>{
                booksArray.push($(bookObject).data('book-id'))
            })
            getDataBooksAfterScroll(globalSearch,booksArray)
        }
    });

    $(document).ready(function() {
        window.showSeachText = function(msg) {
            $('.searching_cls').html("Searching... Please, wait.");
        }
    });



    // START: Authors & Books container visibility
    window.onresize = () => {
        checkListsContainerPosition()
    }

    function checkListsContainerPosition() {
        if (this.innerWidth <= 768) {
            $('#website-description-container').appendTo('#content')
            $('.list-visibility-selection').trigger('change')
        }
        else {
            $('#books-list-container').appendTo('#content')
         
            $('#authors-list-container').removeClass('hidden')
            $('#books-list-container').removeClass('hidden')
        }
    }

    $(document).on('change', '.list-visibility-selection', checkListVisibility)

    function checkListVisibility() {
        let listSelected = $('.list-visibility-selection:checked').val()
        console.log(listSelected)
        if (listSelected == 'authors') {
            $('#authors-list-container').removeClass('hidden')
            $('#books-list-container').addClass('hidden')
        }
        else if (listSelected == 'books') {
            $('#authors-list-container').addClass('hidden')
            $('#books-list-container').removeClass('hidden')
        }
    }

    $(document).ready(function() {
        checkListsContainerPosition();
    });
    // END: Authors & Books container visibility
</script>


